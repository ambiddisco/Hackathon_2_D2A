utils::globalVariables(c("canton", "name", "avg", "x", "y", "value", "X", "Y", "label"))
# 